# Comparador de IAs

Este é um projeto simples em Flask que compara as respostas de duas inteligências artificiais: **OpenAI (ChatGPT)** e **DeepSeek**. O usuário envia uma pergunta e vê lado a lado as respostas de cada IA.

## 💻 Tecnologias

- Python 3.10+
- Flask
- HTML/CSS (Jinja2)
- APIs: OpenAI e DeepSeek

---

## 🚀 Como executar localmente

1. Clone o repositório:

```bash
git clone https://github.com/seu-usuario/seu-repositorio.git
cd seu-repositorio
```

2. Crie e configure o arquivo `.env` com suas chaves:

```
OPENAI_API_KEY=sua-chave-openai-aqui
DEEPSEEK_API_KEY=sua-chave-deepseek-aqui
```

3. Instale as dependências:

```bash
pip install -r requirements.txt
```

4. Execute a aplicação:

```bash
python app.py
```

Acesse em: [http://localhost:5000](http://localhost:5000)

---

## 🌍 Hospedagem gratuita (Render)

### Etapas:

1. Crie uma conta em [https://render.com](https://render.com)
2. Crie um novo Web Service conectado ao GitHub
3. Configure:
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `python app.py`
   - **Runtime:** Python
4. Adicione as variáveis de ambiente:
   - `OPENAI_API_KEY`
   - `DEEPSEEK_API_KEY`
5. Aguarde o deploy e acesse seu site pela URL gerada!

---

## 📄 Licença

Este projeto é livre para fins educacionais.
