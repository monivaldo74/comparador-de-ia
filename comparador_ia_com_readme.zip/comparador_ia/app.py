from flask import Flask, request, render_template
import requests
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")

def consultar_openai(pergunta):
    try:
        resposta = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "user", "content": pergunta}]
            }
        )
        return resposta.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"[Erro OpenAI] {e}"

def consultar_deepseek(pergunta):
    try:
        resposta = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": pergunta}]
            }
        )
        return resposta.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"[Erro DeepSeek] {e}"

@app.route("/", methods=["GET", "POST"])
def index():
    pergunta = ""
    resposta_openai = ""
    resposta_deepseek = ""

    if request.method == "POST":
        pergunta = request.form["pergunta"]
        resposta_openai = consultar_openai(pergunta)
        resposta_deepseek = consultar_deepseek(pergunta)

    return render_template("index.html", pergunta=pergunta,
                           resposta_openai=resposta_openai,
                           resposta_deepseek=resposta_deepseek)

if __name__ == "__main__":
    app.run(debug=True)
